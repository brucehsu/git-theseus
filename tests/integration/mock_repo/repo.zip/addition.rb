# Module Fetchable
# Allow class to utilize this mixin to fetch storage with given key

module Fetchable

    # @params string(key)
    def fetch(key)
        @storage[key]
    end
end