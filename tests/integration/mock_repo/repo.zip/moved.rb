class MyArray
    include Iterable
end
