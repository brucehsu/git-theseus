module Iterable
    def index
        @cursor
    end
end