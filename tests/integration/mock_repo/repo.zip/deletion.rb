module Iterable
    def index
    end
end